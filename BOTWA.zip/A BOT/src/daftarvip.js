const daftarvip = (prefix) => { 
	return `
	
*HARGA DAFTAR VIP :*
-Rp. 10K > Akses Fitur ViP
-Rp. 15K > Fitur VIP + Masukin Bot KeGrup Kalian!

*JIKA INGIN DAFTAR VIP :*
*Chat Owner BOT :*
_wa.me/6287720646259 atau ketik *${prefix}owner*

*NOTE*

*GRUP WHATSAPP BOT :*
_https://chat.whatsapp.com/JRlnBMbOvxq9Y0xzBJGgfI `
}
exports.daftarvip = daftarvip