const makermenu = (prefix) => { 
	return `
╭┤MAKER│
├
╰────────────────────╯`
}
exports.makermenu = makermenu