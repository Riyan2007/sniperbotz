const searchmenu = (prefix) => { 
	return `
╭┤SEARCH│
├ 
╰────────────────────╯`
}
exports.searchmenu = searchmenu