const vipmenu = (prefix) => { 
	return `
╭┤PREMIUM│
├ 
╰────────────────────╯`
}
exports.vipmenu = vipmenu