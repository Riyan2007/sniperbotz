const nsfwmenu = (prefix) => { 
	return `
╭┤NSFW│
├ 
╰────────────────────╯`
}
exports.nsfwmenu = nsfwmenu