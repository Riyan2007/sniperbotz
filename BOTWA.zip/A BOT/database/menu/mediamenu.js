const mediamenu = (prefix) => { 
	return `

╭┤MEDIA│
├ *${prefix}stiker*
├ *${prefix}stikergif*
├ *${prefix}gifttp*
├ *${prefix}nulis
├ *${prefix}ttp*
├ *${prefix}ocr*
├ *${prefix}nobg*
├ *${prefix}toimg*
├ *${prefix}fb*
├ *${prefix}ytmp3*
├ *${prefix}ytmp4*
├ *${prefix}tiktok*
├ *${prefix}fototiktok*
├ *${prefix}tiktokstalk*
├ *${prefix}igstalk*
├ *${prefix}pictcowok*
├ *${prefix}pictcewek*
├ *${prefix}picthewan*
├ *${prefix}pictvtuber*
├ *${prefix}gambar*
├ *${prefix}googleimage*
├ *${prefix}burning*
├ *${prefix}triggerd [reply img]*
├ *${prefix}aesthetic*
├ *${prefix}walpaper*
├ *${prefix}glass*
├ *${prefix}wasted*
├ *${prefix}music*
├ *${prefix}getpic*
├ *${prefix}jomblo*
├ *${prefix}firestik*
├ *${prefix}tomp3*
├ *${prefix}toptt*
├ *${prefix}mp3toptt*
├ *${prefix}pelangi*
├ *${prefix}imagepest*
├ *${prefix}agung*
├ *${prefix}slink*
├ *${prefix}qrcode*
├ *${prefix}play*
├ *${prefix}joox*
├ *${prefix}img2url*
├ *${prefix}url2img*
├ *${prefix}hewan*
├ *${prefix}ssweb*
├ *${prefix}bungasakura*
├ *${prefix}imoji*
├ *${prefix}semoji*
├ *${prefix}randomcat*
├ *${prefix}amv*
├ *${prefix}audio*
├ *${prefix}image*
├ *${prefix}pintrest*
├ *${prefix}elang*
├ *${prefix}anjing
├ *${prefix}unta*
╰────────────────────╯`
}
exports.mediamenu = mediamenu