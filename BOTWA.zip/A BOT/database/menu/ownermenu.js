const ownermenu = (prefix) => { 
	return `
╭┤OWNER│
├
╰────────────────────╯`
}
exports.ownermenu = ownermenu