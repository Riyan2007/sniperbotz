const soundmenu = (prefix) => { 
	return `
╭┤SOUND│
├ 
╰────────────────────╯`
}
exports.soundmenu = soundmenu