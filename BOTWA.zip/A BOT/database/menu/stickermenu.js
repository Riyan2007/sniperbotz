const stickermenu = (prefix) => { 
	return `
╭┤STICKER│
├ 
╰────────────────────╯`
}
exports.stickermenu = stickermenu